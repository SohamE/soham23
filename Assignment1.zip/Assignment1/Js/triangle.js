function area() {
    var a = Number(document.forminp.side1.value);
    console.log(a * 2);
    var b = Number(document.forminp.side2.value);
    var c = Number(document.forminp.side3.value);
    var p = (a + b + c) / 2;
    var area = p * (p - a) * (p - b) * (p - c);
    document.getElementById("result").innerHTML =
        "The Area of the given triangle is " + Math.sqrt(area);
}
