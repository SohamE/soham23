function guess() {
    var a = Math.floor(Math.random() * 11);
    var b = Number(prompt("Input a number between 1 to 10"));
    console.log(a);
    if (a === b) document.getElementById("result").innerText = "GoodWork!";
    else document.getElementById("result").innerText = "Try Again!";
    document.getElementById("guess").value = "";
}
